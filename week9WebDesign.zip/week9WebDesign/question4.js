var presetArray = [23,32,65,49,82,22,10,87]

//function to print array
function printArrayToScreen(){
    var outputElement = document.getElementById('arrayList');
        var arrayPrinted = presetArray.join(', ');
        outputElement.innerHTML = 'Array contains... [' + arrayPrinted + ']';
}

function findLargestNumber(){
    let largestNumber = presetArray[0];
     for (let i = 1; i < presetArray.length; i++) {
            if (presetArray[i] > largestNumber) {
                largestNumber = presetArray[i];}

     }
      var outputElement = document.getElementById('findLargestNo');
         outputElement.innerHTML = 'Largest Number in array: ' + largestNumber;
     }


printArrayToScreen();
